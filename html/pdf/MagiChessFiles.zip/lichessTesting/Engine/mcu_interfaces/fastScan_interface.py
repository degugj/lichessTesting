""" fast scan physical board state """
def scan_board():
	return


""" check for change in game state of physical board """
def boardstate_change():
	return