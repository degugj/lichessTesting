Arduino Code for MDR Demos
