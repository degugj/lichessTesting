from Engine import audio

audio.test()